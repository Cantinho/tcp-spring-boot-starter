package br.com.cantinho.tcpspringbootstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TcpSpringBootStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TcpSpringBootStarterApplication.class, args);
	}
}
